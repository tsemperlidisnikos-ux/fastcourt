# FastCourt Next

Next.js migration for FastCourt — tactical basketball play designer.

**Build:** `next-v7`

## Visual parity rule

Every migrated screen reuses **legacy FastCourt CSS class names and layout** from `c:\fastcourt` (`fastdraw-ui.css`, `library-laptop-fastdraw.css`). New React components map 1:1 to the PWA DOM — not a generic Tailwind redesign.

## Quick start

```bash
cd c:\fastcourt-next
npm install
npm run dev
```

Open `http://localhost:3000` → redirects to `/library`.

Optional cloud mode: copy `.env.example` → `.env.local` and fill Supabase credentials.

## Migration status

> Full gap analysis: [`AUDIT.md`](./AUDIT.md) (updated 2026-06-12)

| Screen | Parity |
|--------|--------|
| **Library — Draw** | FastDraw table + split preview + filter bar + import/clean/bulk |
| **Library — Playbooks / Fields** | Ported |
| **Library — Practice** | Partial (simpler than legacy) |
| **Login / Welcome** | Welcome screen + OAuth + signup wizard |
| **Designer — core** | Konva tools, frames, formations, whiteboard, animation |
| **Designer — exports** | Missing (share, print, PNG/WebM from designer menu) |
| **Settings — Coach / Admin** | Substantial panels; cloud sync + device limits stubbed |
| **PlayBank / Free-draw** | Not ported |
| **Cloud library sync** | Not wired (Phase 4) |
| **PWA / offline** | Manifest only (Phase 5) |

## Phases

| Phase | Status |
|-------|--------|
| 0–3 | Scaffold, auth, Konva, IndexedDB, `.fdb` import |
| **4** | Visual parity QA + **cloud sync** ← current focus |
| 5 | PWA, presentation QA, production cutover |

## Scripts

```bash
npm run dev
npm run build
npm run lint
```

Legacy PWA: `c:\fastcourt`
